# EXPERIMENT: variable-hold (delete this whole file together with the feature)
import json
import tempfile
from dataclasses import replace

import numpy as np
import pytest
import torch

from train import train
from util.checkpoint import load_run, make_players, run_path
from util.ipa import plan_to_ipa
from world.config import Config, build
from world.datatypes import Posture
from world.players.base import ArticulatedSpeaker

SMALL = {"shape": ["a", "b", "c"], "colour": ["x", "y", "z"]}


def made(variable_hold: bool, **extra):
    config = Config(attributes=SMALL, held_out=0.0, hidden=16, arch="rnn", variable_hold=variable_hold, run_dir="", **extra)
    world = build(config)
    torch.manual_seed(0)
    speaker, _ = make_players(config, world)
    return config, world, speaker


def test_each_sound_gets_its_own_length():
    config, world, speaker = made(True, wobble=0.0)
    speaker.act(world.space.all_objects()[0])
    holds = speaker.get_holds()
    assert len(holds) == config.max_slots and all(1 <= h <= config.max_hold for h in holds)
    assert len(set(holds)) > 1
    assert len(speaker.state) - 1 == sum(holds)


def test_it_starts_out_exactly_like_the_fixed_hold():
    plans = []
    for variable in (False, True):
        config, world, speaker = made(variable, wobble=0.0)
        speaker.exploring = False
        speaker.act(world.space.all_objects()[0])
        plans.append((speaker.get_holds(), speaker.get_positions()))
    assert plans[1][0] == [config.hold] * config.max_slots
    assert plans[0][0] == plans[1][0] and np.array_equal(plans[0][1], plans[1][1])


def test_a_longer_hold_lets_the_mouth_arrive():
    class Held(ArticulatedSpeaker):
        def __init__(self, holds, **kw):
            super().__init__(max_slots=1, **kw)
            self.chosen = holds

        def plan_postures(self, obj):
            self.holds = list(self.chosen)
            return [Posture.make([0.0, 1.0, 0.5, 1.0, 0.0])]

    config, world, _ = made(False, wobble=0.0)
    gap = {}
    for frames in (2, 8):
        speaker = Held([frames], mouth=world.mouth, wobble=0.0)
        speaker.act(world.space.all_objects()[0])
        gap[frames] = abs(speaker.state[frames].position[0] - 0.0)
    assert len(speaker.state) - 1 == 8 and gap[8] < gap[2]


def test_time_pressure_shortens_sounds_and_its_absence_does_not():
    def mean_hold(reward_per_frame: float) -> float:
        config, world, speaker = made(True, wobble=0.0, speaker_lr=3e-2)
        speaker.explore = 0.5
        for _ in range(60):
            for obj in world.space.all_objects()[:8]:
                sounds, _ = speaker.act(obj)
                speaker.learn(obj, reward_per_frame * len(sounds))
            speaker.update()
        speaker.exploring = False
        speaker.act(world.space.all_objects()[0])
        return float(np.mean(speaker.get_holds()))

    assert mean_hold(-0.05) < 3.0 < 5.0 < mean_hold(0.05)


def test_the_plan_is_read_with_each_targets_own_length():
    config, world, _ = made(False)
    closure = Posture.make([0.0, 1.0, 2.5 / 7, 1.0, 1.0])
    vowel = Posture.make([1.0, 0.0, 2.5 / 7, 1.0, 1.0])
    assert plan_to_ipa([closure, vowel], world.mouth, [2, 4]) == "ɾɐ"
    assert plan_to_ipa([closure, vowel], world.mouth, [4, 4]) == "dɐ"
    assert plan_to_ipa([closure, vowel], world.mouth, 4) == "dɐ"


def test_a_feedback_speaker_moves_for_as_long_as_it_chose():
    config, world, speaker = made(True, wobble=0.0, feedback=True)
    speaker.act(world.space.all_objects()[0])
    assert len(speaker.state) - 1 == sum(speaker.get_holds())
    assert len(speaker.get_postures()) == speaker.span[1]


def test_runs_save_load_and_cannot_be_resumed_with_it_off():
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(attributes=SMALL, held_out=0.0, steps=4, batch=4, report_every=2, save_every=2, hidden=16,
                        run_dir=tmp, arch="rnn", variable_hold=True, max_hold=12)
        _, speaker, _ = train(config, log=lambda _: None)
        run = load_run(run_path(config))
        assert run.speaker.variable_hold and run.speaker.hold_head.longest == 12
        for a, b in zip(speaker.hold_head.parameters(), run.speaker.hold_head.parameters()):
            assert torch.equal(a, b)
        with pytest.raises(ValueError):
            load_run(run_path(config), replace(config, variable_hold=False))


def test_runs_saved_before_the_setting_existed_load_with_it_off():
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(attributes=SMALL, held_out=0.0, steps=2, batch=4, report_every=2, save_every=2, hidden=16,
                        run_dir=tmp, arch="rnn")
        train(config, log=lambda _: None)
        meta_path = run_path(config) / "run.json"
        meta = json.loads(meta_path.read_text())
        for name in ("variable_hold", "max_hold", "time_cost"):
            del meta["config"][name]
        meta_path.write_text(json.dumps(meta))
        run = load_run(run_path(config))
        assert run.config.variable_hold is False and run.speaker.hold_head is None


def test_the_longest_hold_cannot_be_shorter_than_the_normal_one():
    with pytest.raises(ValueError):
        train(Config(attributes=SMALL, steps=1, batch=2, hidden=16, run_dir="", arch="rnn", variable_hold=True, hold=4, max_hold=2),
              log=lambda _: None)
