# EXPERIMENT: feedback (delete this whole file together with the feature)
import json
import tempfile
from dataclasses import replace

import numpy as np
import pytest
import torch

from train import train
from util.checkpoint import load_run, make_players, run_path
from world.config import Config, build
from world.players.base import ArticulatedSpeaker

SMALL = {"shape": ["a", "b", "c"], "colour": ["x", "y", "z"]}


def made(feedback: bool, **extra):
    config = Config(attributes=SMALL, held_out=0.0, hidden=16, arch="rnn", feedback=feedback, run_dir="", **extra)
    world = build(config)
    speaker, _ = make_players(config, world)
    speaker.exploring = False
    return config, world, speaker


def test_speaker_input_grows_by_what_it_feels():
    plain, felt = made(False)[2], made(True)[2]
    assert felt.cell.input_size == plain.cell.input_size + plain.FELT == plain.cell.input_size + 10


def test_feedback_changes_the_plan_not_the_physics():
    class Replay(ArticulatedSpeaker):
        plan: list = []

        def plan_postures(self, obj):
            return self.plan

    torch.manual_seed(0)
    config, world, speaker = made(True, wobble=0.0)
    obj = world.space.all_objects()[0]
    spoken, effort = speaker.act(obj)
    replay = Replay(max_slots=config.max_slots, mouth=world.mouth, hold=config.hold, wobble=0.0)
    replay.plan = speaker.get_targets()
    replayed, replay_effort = replay.act(obj)
    assert len(spoken) == len(replayed) and effort == pytest.approx(replay_effort)
    assert np.array_equal(speaker.get_positions(), replay.get_positions())


def test_only_a_feedback_speaker_reacts_to_where_its_mouth_landed():
    plans = {}
    for feedback in (False, True):
        torch.manual_seed(0)
        _, world, speaker = made(feedback, wobble=0.15)
        obj = world.space.all_objects()[0]
        runs = []
        for _ in range(2):
            speaker.act(obj)
            runs.append(np.array([t.position for t in speaker.get_targets()]))
        plans[feedback] = runs
    assert np.array_equal(*plans[False])
    assert not np.array_equal(*plans[True])


def test_feedback_runs_save_load_and_cannot_be_resumed_with_it_off():
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(attributes=SMALL, held_out=0.0, steps=4, batch=4, report_every=2, save_every=2, hidden=16,
                        run_dir=tmp, arch="rnn", feedback=True)
        train(config, log=lambda _: None)
        run = load_run(run_path(config))
        assert run.config.feedback and run.speaker.feedback
        with pytest.raises(ValueError):
            load_run(run_path(config), replace(config, feedback=False))


def test_runs_saved_before_the_setting_existed_load_with_it_off():
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(attributes=SMALL, held_out=0.0, steps=2, batch=4, report_every=2, save_every=2, hidden=16,
                        run_dir=tmp, arch="rnn")
        train(config, log=lambda _: None)
        meta_path = run_path(config) / "run.json"
        meta = json.loads(meta_path.read_text())
        del meta["config"]["feedback"]
        meta_path.write_text(json.dumps(meta))
        assert load_run(run_path(config)).config.feedback is False
