"""
ear? no for now
"""


"""
mouth
move() -> effort


"""

from abc import ABC, abstractmethod

from world.datatypes import Motion, Posture, Sound

class Mouth(ABC):
    @property
    @abstractmethod
    def rest(self) -> Posture: ...

    @abstractmethod
    def reach(self, target: Posture) -> Motion: ...

    @abstractmethod
    def move(self, state: Posture, motion: Motion) -> tuple[Posture, float]: ...

    @abstractmethod
    def sound(self, state: Posture) -> Sound: ...
