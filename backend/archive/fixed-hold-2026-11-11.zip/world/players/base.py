#TODO
"""
Speaker
- speak(obj)->msg abstract
- start_word

Listener
- guess(msg)->ans
"""


from abc import ABC, abstractmethod

from world.anatomy.base import Mouth
from world.datatypes import Sound, Object, Motion, Posture

import numpy as np

class Speaker(ABC):
    def __init__(self, max_slots: int) -> None:
        self.max_slots = max_slots

    @abstractmethod
    def act(self, obj: Object) -> tuple[list[Sound], float]:
        ...

    def get_positions(self) -> np.ndarray:
        return np.zeros((0, 5))

    def get_targets(self) -> list[Posture]:
        return []


class ArticulatedSpeaker(Speaker):
    def __init__(self, max_slots: int, mouth: Mouth, hold: int = 4, wobble: float = 0.15,
                 silence_frames: int = 8, silence_level: float = 0.05, seed=None) -> None:
        super().__init__(max_slots)
        self.mouth = mouth
        self.hold = hold
        self.wobble = wobble
        self.silence_frames = silence_frames
        self.silence_level = silence_level
        self.rng = np.random.default_rng(seed)
        self.start_new()

    def act(self, obj: Object) -> tuple[list[Sound], float]:
        self.start_new()
        self.targets = self.plan_postures(obj)[:self.max_slots]
        self.motions = [self.mouth.reach(target) for target in self.targets]
        postures, efforts = self.process_motion(self.motions)
        sounds = self.render_sound(postures)
        self.span = self.word_span(sounds)
        start, end = self.span
        return sounds[start:end], float(sum(efforts[:end]))

    def start_new(self):
        self.targets : list[Posture] = []
        self.motions : list[Motion] = []
        self.state : list[Posture] = [self.mouth.rest]
        self.span : tuple[int, int] = (0, 0)
        self.efforts : list[float] = []  # EXPERIMENT: feedback
        self.holds : list[int] = []  # EXPERIMENT: variable-hold

    @abstractmethod
    def plan_postures(self, obj: Object) -> list[Posture]: #TODO space for RL model to spit something out
        ...

    def process_motion(self, movements: list[Motion]) -> tuple[list[Posture], list[float]]:
        if not self.efforts:  # EXPERIMENT: feedback (a feedback speaker has already moved the mouth while planning)
            for intended, frames in zip(movements, self.holds_for(len(movements))):  # EXPERIMENT: variable-hold
                self.execute(intended, frames)

        return self.state[1:], self.efforts

    # EXPERIMENT: feedback
    def execute(self, intended: Motion, frames: int | None = None) -> None:  # EXPERIMENT: variable-hold (frames was always self.hold)
        slipped = intended.toArray() + self.wobble * self.rng.standard_normal(5)
        actual = Motion.make(np.clip(slipped, -1.0, 1.0))
        for _ in range(frames or self.hold):
            posture, delta = self.mouth.move(self.state[-1], actual)
            self.state.append(posture)
            self.efforts.append(delta)

    # EXPERIMENT: feedback. What the speaker feels of its own mouth right now: where each articulator is and how fast it moves.
    FELT = 10

    def feel(self) -> np.ndarray:
        now = self.state[-1]
        return np.concatenate([now.position, now.velocity])

    def render_sound(self, postures: list[Posture]) -> list[Sound]:
        return [self.mouth.sound(p) for p in postures]

    def word_span(self, sounds: list[Sound]) -> tuple[int, int]:
        loud = [sum(s.f) >= self.silence_level for s in sounds]
        if True not in loud:
            return (0, 0)
        start = loud.index(True)
        end, quiet = start + 1, 0
        for t in range(start + 1, len(loud)):
            if loud[t]:
                end, quiet = t + 1, 0
            else:
                quiet += 1
                if quiet >= self.silence_frames:
                    break
        return (start, end)

    def get_attempted_motions(self) -> np.ndarray:
        return np.array([m.toArray() for m in self.motions])

    def get_targets(self) -> list[Posture]:
        return list(self.targets)

    # EXPERIMENT: variable-hold. How many frames each target was held: the fixed hold, unless the speaker chose its own.
    def get_holds(self) -> list[int]:
        return self.holds_for(len(self.targets))

    def holds_for(self, count: int) -> list[int]:
        return (self.holds + [self.hold] * count)[:count]

    # EXPERIMENT: variable-hold. How many targets lasted into the audible word, so learn() only credits those.
    def used_slots(self) -> int:
        ends = np.cumsum(self.get_holds())
        return max(1, min(int(np.searchsorted(ends, self.span[1])) + 1, len(ends)))

    def get_postures(self) -> list[Posture]:
        return self.state[1:][:self.span[1]]

    def get_positions(self) -> np.ndarray:
        start, end = self.span
        return np.array([p.position for p in self.state[1:][start:end]]).reshape(-1, 5)


class Listener(ABC):
    @abstractmethod
    def act(self, msg: list[Sound]) -> Object:
        pass
