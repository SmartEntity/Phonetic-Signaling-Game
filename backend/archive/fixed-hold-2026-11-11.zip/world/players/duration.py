# EXPERIMENT: variable-hold
"""Lets a speaker choose how long to hold each sound, instead of every sound lasting the same few frames."""

import math

import torch
from torch import nn


class DurationHead(nn.Module):
    """Reads the speaker's memory and picks a number of frames for the sound it is about to make.

    The choice is made on a log scale: a spread of 0.5 means "about 1.6 times longer or shorter", whether the
    sound is 2 frames or 20. It starts out choosing `start` frames, so training begins from the fixed hold.
    """

    def __init__(self, hidden: int, start: int, longest: int) -> None:
        super().__init__()
        self.out = nn.Linear(hidden, 1)
        nn.init.zeros_(self.out.weight)
        nn.init.constant_(self.out.bias, math.log(start))
        self.longest = longest

    def forward(self, memory: torch.Tensor, spread: float, sample: bool) -> tuple[int, torch.Tensor]:
        centre = self.out(memory)
        guess = torch.distributions.Normal(centre, spread)
        log_frames = guess.sample() if sample else centre.detach()
        frames = int(torch.exp(log_frames).round().clamp(1, self.longest).item())
        return frames, guess.log_prob(log_frames).sum()
