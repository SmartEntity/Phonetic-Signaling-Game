import sys
from dataclasses import fields, replace
from pathlib import Path

import torch

from util.checkpoint import Run, TrainableListener, TrainableSpeaker, exists, load_run, make_players, run_path, save_run
from util.ipa import lexicon
from world.config import Config, World, build
from world.game import Game


def train(config: Config, log=print, resume: bool = False) -> tuple[World, TrainableSpeaker, TrainableListener]:
    path = run_path(config) if config.run_dir else None

    if resume and path is not None and exists(path):
        run = load_run(path, config)
        world, speaker, listener, history, start = run.world, run.speaker, run.listener, run.history, run.step + 1
        log(f"resuming {path} from step {run.step}")
    else:
        if path is not None and exists(path):
            raise FileExistsError(f"{path} already holds a run. Add resume=1 to continue it, or set run_name=<new name>.")
        torch.manual_seed(config.seed)
        world = build(config)
        speaker, listener = make_players(config, world)
        history, start = [], 0
    if config.reward not in ("confidence", "logprob"):  # EXPERIMENT: logprob-reward
        raise ValueError(f"reward must be 'confidence' or 'logprob', not {config.reward!r}")  # EXPERIMENT: logprob-reward
    if config.variable_hold and config.max_hold < config.hold:  # EXPERIMENT: variable-hold
        raise ValueError(f"max_hold ({config.max_hold}) must be at least hold ({config.hold})")  # EXPERIMENT: variable-hold
    game = Game(speaker, listener, world.channel)

    def save(step: int) -> None:
        if path is not None:
            save_run(path, Run(config, world, speaker, listener, history, step))

    last = start - 1
    for step in range(start, config.steps + 1):
        speaker.explore = config.explore + (config.explore_end - config.explore) * min(1.0, step / max(1, config.steps))  # EXPERIMENT: explore-decay
        for i in world.train_rng.integers(len(world.seen), size=config.batch):
            obj = world.seen[i]
            summary = game.play_rnd(obj)
            listener.learn(obj)
            heard = listener.log_confidence(obj) if config.reward == "logprob" else listener.confidence(obj)  # EXPERIMENT: logprob-reward
            reward = heard - config.effort_cost * summary.effort
            if config.variable_hold:  # EXPERIMENT: variable-hold (time is not free, so slow words cost more)
                reward -= config.time_cost * len(summary.spoken)  # EXPERIMENT: variable-hold
            speaker.learn(obj, reward)
        speaker.update()
        listener.update()
        last = step

        if step % config.report_every == 0:
            speaker.exploring = False
            seen, held = game.evaluate(world.seen, 3), game.evaluate(world.held, 3)
            speaker.exploring = True
            history.append(dict(step=step, seen=seen["correct"], held_out=held["correct"], effort=seen["effort"], frames=seen["frames"]))
            log(f"step {step:6d}   seen {seen['correct']:.2f}   held out {held['correct']:.2f}   "
                f"effort {seen['effort']:.1f}   frames {seen['frames']:.1f}")
        if config.save_every and step % config.save_every == 0:
            save(step)

    if last >= start and not (config.save_every and last % config.save_every == 0):
        save(last)
    if path is not None and last >= start:
        log(f"saved to {path}")
    return world, speaker, listener


def main():
    defaults = Config()
    names = {f.name for f in fields(Config)}
    changes, resume = {}, False
    for arg in sys.argv[1:]:
        name, value = arg.split("=", 1)
        if name == "resume":
            resume = value not in ("0", "false", "no")
            continue
        if name not in names:
            raise SystemExit(f"unknown setting {name!r}; choose from {sorted(names | {'resume'})}")
        kind = type(getattr(defaults, name))
        if kind is bool:  # EXPERIMENT: feedback
            changes[name] = value not in ("0", "false", "no")  # EXPERIMENT: feedback
            continue  # EXPERIMENT: feedback
        if kind not in (int, float, str):
            raise SystemExit(f"{name} can't be set from the command line")
        changes[name] = kind(value)
    world, speaker, listener = train(replace(defaults, **changes), resume=resume)

    speaker.exploring = False
    print()
    for obj, (meant, said) in lexicon(speaker, world.space.all_objects(), simple=True).items():
        print(f"{'held out' if obj in world.held else '':9s} {str(obj):16s} meant {meant}   said {said}")


if __name__ == "__main__":
    main()
